// 다국어 데이터 및 지점 정보
const i18nData = {
  ko: {
    heroBadge: "K-Beauty & Dermatology",
    heroTitle: "Discover Pure<br>Wellness Spaces",
    heroDesc: "전문 약사진의 맞춤형 더마 스킨케어와 100% 현장 즉시 면세 혜택.",
    badgeTax: "100% 즉시 면세",
    badgeConsult: "전문 피부 상담",
    filterRegionLabel: "지역 선택",
    filterHoursLabel: "운영 서비스",
    filterHoursVal: "마감 심야 & 면세",
    optAll: "전체 지점 (4)",
    optSeoul: "서울 (강남 / 명동)",
    optJeju: "제주 (노연로)",
    channelsTitle: "공식 채널",
    branchTitle: "추천 지점 안내",
    taxNotice: "전 지점 여권 제시 시 100% 현장 즉시 환급(Tax Refund)",
    btnNaver: "네이버",
    btnKakao: "카카오",
    btnGoogle: "구글맵",
    branches: [
      {
        id: "gangnam",
        region: "seoul",
        cityTag: "SEOUL • GANGNAM",
        name: "강남 본점",
        sub: "뷰티 메인 스트리트",
        address: "서울 강남구 강남대로 390 1층",
        hours: "09:00 - 22:30",
        desc: "강남역 메인 뷰티거리 • 전문 더마톨로지 처방 큐레이션",
        image: "https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleGangnam",
        kakao: "https://kko.to/exampleGangnam",
        google: "https://maps.google.com/?q=Gangnam+Eight+Pharmacy"
      },
      {
        id: "md1",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "명동 1호점",
        sub: "글로벌 쇼핑 중심지",
        address: "서울 중구 명동8길 27 1층",
        hours: "09:00 - 23:00 (마감 심야 운영)",
        desc: "명동역 도보 1분 • 외국인 여행자 전용 즉시 면세 데스크",
        image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong1",
        kakao: "https://kko.to/exampleMyeongdong1",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+1"
      },
      {
        id: "md2",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "명동 2호점",
        sub: "NYUNYU 맞은편",
        address: "서울 중구 명동4길 15 1층",
        hours: "10:00 - 23:30 (마감 심야 운영)",
        desc: "뉴뉴(NYUNYU) 매장 정면 • 심야 웰니스 및 스킨케어 상담",
        image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong2",
        kakao: "https://kko.to/exampleMyeongdong2",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+2"
      },
      {
        id: "jeju",
        region: "jeju",
        cityTag: "JEJU ISLAND",
        name: "제주점",
        sub: "노연로 웰니스 스팟",
        address: "제주 제주시 노연로 80 1층",
        hours: "09:00 - 22:00",
        desc: "제주 여행 맞춤형 선케어 & 이너뷰티 웰니스 솔루션",
        image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleJeju",
        kakao: "https://kko.to/exampleJeju",
        google: "https://maps.google.com/?q=Jeju+Eight+Pharmacy"
      }
    ]
  },
  en: {
    heroBadge: "K-Beauty & Dermatology",
    heroTitle: "Discover Pure<br>Wellness Spaces",
    heroDesc: "Curated skincare by licensed pharmacists with 100% Tax Refund.",
    badgeTax: "100% Tax Refund",
    badgeConsult: "Skin Consultation",
    filterRegionLabel: "Select Region",
    filterHoursLabel: "Service",
    filterHoursVal: "Night Open & Tax Free",
    optAll: "All Branches (4)",
    optSeoul: "Seoul (Gangnam / Myeongdong)",
    optJeju: "Jeju (Noyeon-ro)",
    channelsTitle: "Official Channels",
    branchTitle: "Featured Locations",
    taxNotice: "Immediate 100% Tax Refund available with your passport.",
    btnNaver: "Naver",
    btnKakao: "Kakao",
    btnGoogle: "Google",
    branches: [
      {
        id: "gangnam",
        region: "seoul",
        cityTag: "SEOUL • GANGNAM",
        name: "Gangnam Flagship",
        sub: "Beauty Main Street",
        address: "1F, 390 Gangnam-daero, Gangnam-gu, Seoul",
        hours: "09:00 - 22:30",
        desc: "Gangnam beauty street • Specialized dermacare solutions",
        image: "https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleGangnam",
        kakao: "https://kko.to/exampleGangnam",
        google: "https://maps.google.com/?q=Gangnam+Eight+Pharmacy"
      },
      {
        id: "md1",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "Myeongdong 1st Store",
        sub: "Global Shopping District",
        address: "1F, 27 Myeongdong 8-gil, Jung-gu, Seoul",
        hours: "09:00 - 23:00 (Night Open)",
        desc: "1 min from Myeongdong Stn • Immediate Tax Refund Counter",
        image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong1",
        kakao: "https://kko.to/exampleMyeongdong1",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+1"
      },
      {
        id: "md2",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "Myeongdong 2nd Store",
        sub: "Opposite NYUNYU",
        address: "1F, 15 Myeongdong 4-gil, Jung-gu, Seoul",
        hours: "10:00 - 23:30 (Night Open)",
        desc: "Directly opposite NYUNYU • Late night skincare consultation",
        image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong2",
        kakao: "https://kko.to/exampleMyeongdong2",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+2"
      },
      {
        id: "jeju",
        region: "jeju",
        cityTag: "JEJU ISLAND",
        name: "Jeju Island Store",
        sub: "Noyeon-ro Wellness",
        address: "1F, 80 Noyeon-ro, Jeju-si, Jeju",
        hours: "09:00 - 22:00",
        desc: "Jeju travel suncare & inner beauty wellness essentials",
        image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleJeju",
        kakao: "https://kko.to/exampleJeju",
        google: "https://maps.google.com/?q=Jeju+Eight+Pharmacy"
      }
    ]
  },
  ja: {
    heroBadge: "K-Beauty & Dermatology",
    heroTitle: "Discover Pure<br>Wellness Spaces",
    heroDesc: "薬剤師が厳選した処方スキンケアと即時免税(Tax Refund)のご案内。",
    badgeTax: "100% 即時免税",
    badgeConsult: "肌悩みカウンセリング",
    filterRegionLabel: "地域選択",
    filterHoursLabel: "営業時間",
    filterHoursVal: "深夜営業 & 免税対応",
    optAll: "全店舗 (4)",
    optSeoul: "ソウル (江南 / 明洞)",
    optJeju: "済州 (老蓮路)",
    channelsTitle: "公式SNS",
    branchTitle: "店舗ロケーション",
    taxNotice: "パスポートご提示で全店舗にて即時免税(Tax Refund)可能です。",
    btnNaver: "Naver",
    btnKakao: "Kakao",
    btnGoogle: "Google",
    branches: [
      {
        id: "gangnam",
        region: "seoul",
        cityTag: "SEOUL • GANGNAM",
        name: "江南(カンナム) 本店",
        sub: "ビューティーストリート",
        address: "ソウル特別市 江南区 江南大路 390 1F",
        hours: "09:00 - 22:30",
        desc: "江南駅メインストリート • 韓国コスメ&処方スキンケア",
        image: "https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleGangnam",
        kakao: "https://kko.to/exampleGangnam",
        google: "https://maps.google.com/?q=Gangnam+Eight+Pharmacy"
      },
      {
        id: "md1",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "明洞(ミョンドン) 1号店",
        sub: "ショッピングの中心",
        address: "ソウル特別市 中区 明洞8キル 27 1F",
        hours: "09:00 - 23:00 (夜間営業)",
        desc: "明洞駅徒歩1分 • パスポート提示で即時免税カウンター完備",
        image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong1",
        kakao: "https://kko.to/exampleMyeongdong1",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+1"
      },
      {
        id: "md2",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "明洞(ミョンドン) 2号店",
        sub: "NYUNYUの正面",
        address: "ソウル特別市 中区 明洞4キル 15 1F",
        hours: "10:00 - 23:30 (夜間営業)",
        desc: "NYUNYU(ニューニュー)正面 • 深夜スキンケア相談対応",
        image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong2",
        kakao: "https://kko.to/exampleMyeongdong2",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+2"
      },
      {
        id: "jeju",
        region: "jeju",
        cityTag: "JEJU ISLAND",
        name: "済州(チェジュ) 店",
        sub: "済州ウェルネス",
        address: "済州特別自治道 済州市 老蓮路 80 1F",
        hours: "09:00 - 22:00",
        desc: "済州旅行おすすめ薬局 • サンケア&ビタミン補給",
        image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleJeju",
        kakao: "https://kko.to/exampleJeju",
        google: "https://maps.google.com/?q=Jeju+Eight+Pharmacy"
      }
    ]
  },
  zh: {
    heroBadge: "K-Beauty & Dermatology",
    heroTitle: "Discover Pure<br>Wellness Spaces",
    heroDesc: "专业药剂师精选药妆护肤系列与现场即时退税(Tax Refund)指南。",
    badgeTax: "100% 现场退税",
    badgeConsult: "专业护肤咨询",
    filterRegionLabel: "选择区域",
    filterHoursLabel: "特色服务",
    filterHoursVal: "夜间营业 & 即时退税",
    optAll: "全部门店 (4)",
    optSeoul: "首尔 (江南 / 明洞)",
    optJeju: "济州岛 (老莲路)",
    channelsTitle: "官方社交媒体",
    branchTitle: "精选门店指南",
    taxNotice: "持护照在所有分店均可享受现场即时退税(Tax Refund)。",
    btnNaver: "Naver地图",
    btnKakao: "Kakao地图",
    btnGoogle: "谷歌地图",
    branches: [
      {
        id: "gangnam",
        region: "seoul",
        cityTag: "SEOUL • GANGNAM",
        name: "江南总店",
        sub: "美妆核心商圈",
        address: "首尔特别市江南区江南大路390 1层",
        hours: "09:00 - 22:30",
        desc: "江南站美妆主街 • 韩国药妆护肤专研",
        image: "https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleGangnam",
        kakao: "https://kko.to/exampleGangnam",
        google: "https://maps.google.com/?q=Gangnam+Eight+Pharmacy"
      },
      {
        id: "md1",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "明洞 1号店",
        sub: "全球购物中心",
        address: "首尔特别市中区明洞8街27 1层",
        hours: "09:00 - 23:00 (夜间营业)",
        desc: "明洞站步行1分钟 • 持护照现场即时退税",
        image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong1",
        kakao: "https://kko.to/exampleMyeongdong1",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+1"
      },
      {
        id: "md2",
        region: "seoul",
        cityTag: "SEOUL • MYEONGDONG",
        name: "明洞 2号店",
        sub: "NYUNYU 对面",
        address: "首尔特别市中区明洞4街15 1层",
        hours: "10:00 - 23:30 (夜间营业)",
        desc: "NYUNYU正对面 • 夜间健康/美肤咨询",
        image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleMyeongdong2",
        kakao: "https://kko.to/exampleMyeongdong2",
        google: "https://maps.google.com/?q=Myeongdong+Eight+Pharmacy+2"
      },
      {
        id: "jeju",
        region: "jeju",
        cityTag: "JEJU ISLAND",
        name: "济州分店",
        sub: "老莲路养生据点",
        address: "济州特别自治道济州市老莲路80 1层",
        hours: "09:00 - 22:00",
        desc: "济州旅行必备 • 防晒修护与健康养护",
        image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=600",
        naver: "https://naver.me/exampleJeju",
        kakao: "https://kko.to/exampleJeju",
        google: "https://maps.google.com/?q=Jeju+Eight+Pharmacy"
      }
    ]
  }
};

let currentLang = "ko";
let currentRegion = "all";

function renderApp() {
  const t = i18nData[currentLang];

  // Update dynamic i18n text
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (t[key]) {
      el.innerHTML = t[key];
    }
  });

  // Filter branches
  const filteredBranches = t.branches.filter((b) => {
    if (currentRegion === "all") return true;
    return b.region === currentRegion;
  });

  // Render branch cards
  const container = document.getElementById("branchList");
  container.innerHTML = filteredBranches
    .map(
      (b) => `
    <article class="branch-showcase-card">
      <div class="card-media" style="background-image: url('${b.image}');">
        <div class="card-media-overlay">
          <span class="card-city-tag">${b.cityTag}</span>
          <span class="card-hours-tag">${b.hours}</span>
        </div>
      </div>
      <div class="card-body">
        <div class="card-header-row">
          <h3 class="card-title">${b.name}</h3>
          <span class="card-subtitle">${b.sub}</span>
        </div>
        <div class="card-address-row">
          <i data-lucide="map-pin"></i>
          <span>${b.address}</span>
        </div>
        <p class="card-desc">${b.desc}</p>
        <div class="map-actions-row">
          <a href="${b.naver}" target="_blank" class="map-link-btn">
            <i data-lucide="navigation"></i> ${t.btnNaver}
          </a>
          <a href="${b.kakao}" target="_blank" class="map-link-btn">
            <i data-lucide="map"></i> ${t.btnKakao}
          </a>
          <a href="${b.google}" target="_blank" class="map-link-btn">
            <i data-lucide="compass"></i> ${t.btnGoogle}
          </a>
        </div>
      </div>
    </article>
  `
    )
    .join("");

  // Reinitialize Lucide Icons
  lucide.createIcons();
}

// Event Listeners
document.querySelectorAll(".lang-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".lang-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentLang = btn.dataset.lang;
    renderApp();
  });
});

document.getElementById("regionFilter").addEventListener("change", (e) => {
  currentRegion = e.target.value;
  renderApp();
});

document.getElementById("searchBtn").addEventListener("click", () => {
  document.getElementById("branchList").scrollIntoView({ behavior: "smooth" });
});

// Initial Run
renderApp();